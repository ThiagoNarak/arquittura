import com.sun.prism.paint.Color;

public class main2 {
    public static void main(String[] args) {
        Emulator emulator = new Emulator(16,16);

        emulator.run();
    }
}
